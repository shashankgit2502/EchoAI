"""
File reader core package.
"""
