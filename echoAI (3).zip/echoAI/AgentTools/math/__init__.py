"""
Math helpers (arithmetic, statistics, linear algebra).
"""
