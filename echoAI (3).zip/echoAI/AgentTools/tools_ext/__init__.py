"""
External tools core package (MCP-agnostic).
"""
