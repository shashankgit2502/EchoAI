"""
Calculator core package.
"""
