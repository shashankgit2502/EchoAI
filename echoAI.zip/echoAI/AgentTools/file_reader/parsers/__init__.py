"""
Document parser implementations.
"""
