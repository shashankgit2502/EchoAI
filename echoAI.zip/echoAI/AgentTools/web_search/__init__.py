# Web Search Tool
# Multi-provider web search service (Google, Bing, DuckDuckGo)
