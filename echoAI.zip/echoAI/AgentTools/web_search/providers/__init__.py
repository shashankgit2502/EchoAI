"""
Web search providers package.
"""
