
import uuid

def new_id(prefix: str = '') -> str:
    return f"{prefix}{uuid.uuid4().hex}"
